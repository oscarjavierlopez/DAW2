<?php
$servername = "localhost";
    $username = "root";
    $password = "";
    $database = "resenias_libros";
?>